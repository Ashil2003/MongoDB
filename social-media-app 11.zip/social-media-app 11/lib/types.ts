import type { ObjectId } from "mongodb"

export interface User {
  _id: string | ObjectId
  name: string
  username: string
  email: string
  avatar: string | null
  bio: string
  createdAt: Date | string
}

export interface Author {
  _id: string | ObjectId
  name: string
  username: string
  avatar: string | null
}

export interface Comment {
  _id: string | ObjectId
  author: Author
  content: string
  createdAt: Date | string
}

export interface Post {
  _id: string | ObjectId
  author: Author
  imageUrl: string
  caption: string
  likes: number
  comments?: Comment[]
  createdAt: Date | string
}

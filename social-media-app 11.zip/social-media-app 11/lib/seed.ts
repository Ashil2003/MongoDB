import { connectToDatabase } from "@/lib/mongodb"
import { hashPassword } from "@/lib/password"

export async function seedDatabase() {
  try {
    const { db } = await connectToDatabase()

    // Check if users collection already has data
    const usersCount = await db.collection("users").countDocuments()

    if (usersCount === 0) {
      console.log("Seeding database with initial data...")

      // Create a test user
      const hashedPassword = await hashPassword("password123")

      const user = {
        name: "Test User",
        username: "testuser",
        email: "test@example.com",
        password: hashedPassword,
        avatar: null,
        bio: "This is a test account",
        createdAt: new Date(),
      }

      const result = await db.collection("users").insertOne(user)

      // Create some sample posts
      const posts = [
        {
          author: {
            _id: result.insertedId,
            name: user.name,
            username: user.username,
            avatar: user.avatar,
          },
          imageUrl: "/placeholder.svg?height=600&width=600&text=Sample+Post+1",
          caption: "This is my first post!",
          likes: 0,
          comments: [],
          createdAt: new Date(),
        },
        {
          author: {
            _id: result.insertedId,
            name: user.name,
            username: user.username,
            avatar: user.avatar,
          },
          imageUrl: "/placeholder.svg?height=600&width=600&text=Sample+Post+2",
          caption: "Enjoying the weekend!",
          likes: 0,
          comments: [],
          createdAt: new Date(Date.now() - 86400000), // 1 day ago
        },
      ]

      await db.collection("posts").insertMany(posts)

      console.log("Database seeded successfully!")
      return { success: true }
    } else {
      console.log("Database already has data, skipping seed")
      return { success: true, skipped: true }
    }
  } catch (error) {
    console.error("Error seeding database:", error)
    return { success: false, error }
  }
}

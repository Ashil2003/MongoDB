import { getPosts } from "@/lib/data"
import PostCard from "@/components/post-card"
import CreatePostButton from "@/components/create-post-button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default async function Feed() {
  const posts = await getPosts()

  return (
    <div className="container mx-auto max-w-4xl px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-3xl font-bold">Snapshare</h1>
        <CreatePostButton />
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="all">All Posts</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
          <TabsTrigger value="trending">Trending</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-6 space-y-6">
          {posts.length > 0 ? (
            posts.map((post) => <PostCard key={post._id} post={post} />)
          ) : (
            <div className="rounded-lg border border-dashed p-8 text-center">
              <h3 className="mb-2 text-xl font-medium">No posts yet</h3>
              <p className="text-muted-foreground">Be the first to share a moment!</p>
            </div>
          )}
        </TabsContent>
        <TabsContent value="following" className="mt-6">
          <div className="rounded-lg border border-dashed p-8 text-center">
            <h3 className="mb-2 text-xl font-medium">Coming soon</h3>
            <p className="text-muted-foreground">Follow users to see their posts here</p>
          </div>
        </TabsContent>
        <TabsContent value="trending" className="mt-6">
          <div className="rounded-lg border border-dashed p-8 text-center">
            <h3 className="mb-2 text-xl font-medium">Coming soon</h3>
            <p className="text-muted-foreground">Trending posts will appear here</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

import { MongoClient, type Db } from "mongodb"

// Default to localhost if no environment variable is set
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/snapshare"

let cachedClient: MongoClient | null = null
let cachedDb: Db | null = null

export async function connectToDatabase() {
  // If we already have a connection, use it
  if (cachedClient && cachedDb) {
    return { client: cachedClient, db: cachedDb }
  }

  // Add error handling for connection
  try {
    const client = await MongoClient.connect(MONGODB_URI)
    console.log("Connected to MongoDB successfully")

    const db = client.db()

    cachedClient = client
    cachedDb = db

    return { client, db }
  } catch (error) {
    console.error("Failed to connect to MongoDB:", error)
    throw new Error("Could not connect to database")
  }
}

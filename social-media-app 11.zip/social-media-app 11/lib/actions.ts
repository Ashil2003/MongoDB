"use server"

import { revalidatePath } from "next/cache"
import { connectToDatabase } from "@/lib/mongodb"
import { hashPassword } from "@/lib/password"
import { ObjectId } from "mongodb"

export async function registerUser(userData: {
  name: string
  username: string
  email: string
  password: string
}) {
  try {
    const { db } = await connectToDatabase()

    // Check if email or username already exists
    const existingUser = await db.collection("users").findOne({
      $or: [{ email: userData.email }, { username: userData.username }],
    })

    if (existingUser) {
      if (existingUser.email === userData.email) {
        return { error: "Email already in use" }
      }
      if (existingUser.username === userData.username) {
        return { error: "Username already taken" }
      }
    }

    // Hash password
    const hashedPassword = await hashPassword(userData.password)

    // Create user
    const result = await db.collection("users").insertOne({
      name: userData.name,
      username: userData.username,
      email: userData.email,
      password: hashedPassword,
      avatar: null,
      bio: "",
      createdAt: new Date(),
    })

    return { success: true, userId: result.insertedId.toString() }
  } catch (error) {
    console.error("Registration error:", error)
    return { error: "Failed to create account" }
  }
}

export async function createPost(formData: FormData) {
  try {
    // In a real app, you would upload the image to a storage service
    // and get back a URL. For this example, we'll simulate it.
    const image = formData.get("image") as File
    const caption = formData.get("caption") as string

    // Simulate image upload and get URL
    // In a real app, use a service like Cloudinary, AWS S3, etc.
    const imageUrl = `/placeholder.svg?height=600&width=600&text=${encodeURIComponent(image.name)}`

    const { db } = await connectToDatabase()

    // Get current user (in a real app, get from session)
    // For this example, we'll use a mock user
    const mockUser = await db.collection("users").findOne({})

    if (!mockUser) {
      throw new Error("User not found")
    }

    await db.collection("posts").insertOne({
      author: {
        _id: mockUser._id,
        name: mockUser.name,
        username: mockUser.username,
        avatar: mockUser.avatar,
      },
      imageUrl,
      caption,
      likes: 0,
      comments: [],
      createdAt: new Date(),
    })

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error("Create post error:", error)
    throw new Error("Failed to create post")
  }
}

export async function likePost(postId: string) {
  try {
    const { db } = await connectToDatabase()

    // In a real app, you would check if the user has already liked the post
    // and toggle the like status accordingly

    await db.collection("posts").updateOne({ _id: new ObjectId(postId) }, { $inc: { likes: 1 } })

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error("Like post error:", error)
    throw new Error("Failed to like post")
  }
}

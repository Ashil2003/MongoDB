"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle2, XCircle, AlertCircle, Database } from "lucide-react"

export default function DebugPage() {
  const [mongoStatus, setMongoStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [mongoMessage, setMongoMessage] = useState("")
  const [seedStatus, setSeedStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [seedMessage, setSeedMessage] = useState("")

  const checkMongoDB = async () => {
    setMongoStatus("loading")
    try {
      const res = await fetch("/api/debug/mongo")
      const data = await res.json()

      if (res.ok) {
        setMongoStatus("success")
        setMongoMessage(data.message)
      } else {
        setMongoStatus("error")
        setMongoMessage(data.error || "Failed to connect to MongoDB")
      }
    } catch (error) {
      setMongoStatus("error")
      setMongoMessage("Network error or API route not found")
    }
  }

  const seedDb = async () => {
    setSeedStatus("loading")
    try {
      const res = await fetch("/api/seed")
      const data = await res.json()

      if (res.ok) {
        setSeedStatus("success")
        setSeedMessage(data.message)
      } else {
        setSeedStatus("error")
        setSeedMessage(data.error || "Failed to seed database")
      }
    } catch (error) {
      setSeedStatus("error")
      setSeedMessage("Network error or API route not found")
    }
  }

  return (
    <div className="container mx-auto max-w-4xl px-4 py-8">
      <h1 className="mb-6 text-3xl font-bold">Application Debug</h1>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              MongoDB Connection
            </CardTitle>
            <CardDescription>Check if your MongoDB connection is working</CardDescription>
          </CardHeader>
          <CardContent>
            {mongoStatus === "success" && (
              <Alert className="mb-4 border-green-500 bg-green-50 text-green-800 dark:bg-green-900/20 dark:text-green-400">
                <CheckCircle2 className="h-4 w-4" />
                <AlertTitle>Success</AlertTitle>
                <AlertDescription>{mongoMessage}</AlertDescription>
              </Alert>
            )}

            {mongoStatus === "error" && (
              <Alert variant="destructive" className="mb-4">
                <XCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{mongoMessage}</AlertDescription>
              </Alert>
            )}

            {mongoStatus === "loading" && (
              <Alert className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Checking connection...</AlertTitle>
                <AlertDescription>Please wait</AlertDescription>
              </Alert>
            )}
          </CardContent>
          <CardFooter>
            <Button onClick={checkMongoDB} disabled={mongoStatus === "loading"}>
              {mongoStatus === "loading" ? "Checking..." : "Check Connection"}
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Seed Database
            </CardTitle>
            <CardDescription>Add sample data to your database</CardDescription>
          </CardHeader>
          <CardContent>
            {seedStatus === "success" && (
              <Alert className="mb-4 border-green-500 bg-green-50 text-green-800 dark:bg-green-900/20 dark:text-green-400">
                <CheckCircle2 className="h-4 w-4" />
                <AlertTitle>Success</AlertTitle>
                <AlertDescription>{seedMessage}</AlertDescription>
              </Alert>
            )}

            {seedStatus === "error" && (
              <Alert variant="destructive" className="mb-4">
                <XCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{seedMessage}</AlertDescription>
              </Alert>
            )}

            {seedStatus === "loading" && (
              <Alert className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Seeding database...</AlertTitle>
                <AlertDescription>Please wait</AlertDescription>
              </Alert>
            )}
          </CardContent>
          <CardFooter>
            <Button onClick={seedDb} disabled={seedStatus === "loading"}>
              {seedStatus === "loading" ? "Seeding..." : "Seed Database"}
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="mt-8 rounded-lg border p-6">
        <h2 className="mb-4 text-xl font-semibold">Troubleshooting Steps</h2>
        <ol className="list-decimal space-y-2 pl-5">
          <li>Make sure MongoDB is running on your local machine</li>
          <li>Check that your environment variables are set correctly</li>
          <li>
            Ensure all dependencies are installed with <code className="rounded bg-muted px-1 py-0.5">npm install</code>
          </li>
          <li>Try seeding the database with sample data using the button above</li>
          <li>
            Restart your development server with <code className="rounded bg-muted px-1 py-0.5">npm run dev</code>
          </li>
        </ol>
      </div>
    </div>
  )
}

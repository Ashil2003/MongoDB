import { NextResponse } from "next/server"
import { seedDatabase } from "@/lib/seed"

export async function GET() {
  try {
    const result = await seedDatabase()

    if (result.success) {
      return NextResponse.json({
        message: result.skipped ? "Database already has data" : "Database seeded successfully",
      })
    } else {
      return NextResponse.json({ error: "Failed to seed database" }, { status: 500 })
    }
  } catch (error) {
    console.error("Seed API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

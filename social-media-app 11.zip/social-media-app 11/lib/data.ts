import { cache } from "react"
import { connectToDatabase } from "@/lib/mongodb"
import type { Post } from "@/lib/types"

export const getPosts = cache(async (): Promise<Post[]> => {
  try {
    const { db } = await connectToDatabase()

    const posts = await db.collection("posts").find({}).sort({ createdAt: -1 }).limit(10).toArray()

    return JSON.parse(JSON.stringify(posts))
  } catch (error) {
    console.error("Error fetching posts:", error)
    return []
  }
})

export const getPostById = cache(async (postId: string): Promise<Post | null> => {
  try {
    const { db } = await connectToDatabase()

    const post = await db.collection("posts").findOne({ _id: postId })

    if (!post) return null

    return JSON.parse(JSON.stringify(post))
  } catch (error) {
    console.error("Error fetching post:", error)
    return null
  }
})

export const getUserByUsername = cache(async (username: string) => {
  try {
    const { db } = await connectToDatabase()

    const user = await db.collection("users").findOne({ username })

    if (!user) return null

    // Remove sensitive information
    delete user.password

    return JSON.parse(JSON.stringify(user))
  } catch (error) {
    console.error("Error fetching user:", error)
    return null
  }
})

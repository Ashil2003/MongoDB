import { notFound } from "next/navigation"
import Image from "next/image"
import { getUserByUsername, getPosts } from "@/lib/data"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Grid, Settings, Users } from "lucide-react"

interface ProfilePageProps {
  params: {
    username: string
  }
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const user = await getUserByUsername(params.username)

  if (!user) {
    notFound()
  }

  const posts = await getPosts()
  const userPosts = posts.filter((post) => post.author.username === params.username)

  return (
    <div className="container mx-auto max-w-4xl px-4 py-8">
      <div className="mb-8 flex flex-col items-center space-y-4 md:flex-row md:space-x-6 md:space-y-0">
        <Avatar className="h-24 w-24 md:h-32 md:w-32">
          <AvatarImage src={user.avatar || "/placeholder.svg?height=128&width=128"} alt={user.name} />
          <AvatarFallback className="text-2xl">{user.name.charAt(0)}</AvatarFallback>
        </Avatar>

        <div className="flex-1 space-y-4 text-center md:text-left">
          <div>
            <h1 className="text-2xl font-bold">{user.name}</h1>
            <p className="text-muted-foreground">@{user.username}</p>
          </div>

          <div className="flex justify-center space-x-6 md:justify-start">
            <div className="text-center">
              <div className="font-bold">{userPosts.length}</div>
              <div className="text-xs text-muted-foreground">Posts</div>
            </div>
            <div className="text-center">
              <div className="font-bold">0</div>
              <div className="text-xs text-muted-foreground">Followers</div>
            </div>
            <div className="text-center">
              <div className="font-bold">0</div>
              <div className="text-xs text-muted-foreground">Following</div>
            </div>
          </div>

          <div>
            <p>{user.bio || "No bio yet"}</p>
          </div>

          <div className="flex space-x-2">
            <Button>Follow</Button>
            <Button variant="outline" size="icon">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <Tabs defaultValue="posts">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="posts">
            <Grid className="mr-2 h-4 w-4" />
            Posts
          </TabsTrigger>
          <TabsTrigger value="saved">
            <Grid className="mr-2 h-4 w-4" />
            Saved
          </TabsTrigger>
          <TabsTrigger value="tagged">
            <Users className="mr-2 h-4 w-4" />
            Tagged
          </TabsTrigger>
        </TabsList>

        <TabsContent value="posts" className="mt-6">
          {userPosts.length > 0 ? (
            <div className="grid grid-cols-3 gap-1">
              {userPosts.map((post) => (
                <div key={post._id.toString()} className="relative aspect-square">
                  <Image src={post.imageUrl || "/placeholder.svg"} alt={post.caption} fill className="object-cover" />
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-lg border border-dashed p-8 text-center">
              <h3 className="mb-2 text-xl font-medium">No posts yet</h3>
              <p className="text-muted-foreground">When you share photos, they will appear here.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="saved" className="mt-6">
          <div className="rounded-lg border border-dashed p-8 text-center">
            <h3 className="mb-2 text-xl font-medium">No saved posts</h3>
            <p className="text-muted-foreground">Save posts to view them later.</p>
          </div>
        </TabsContent>

        <TabsContent value="tagged" className="mt-6">
          <div className="rounded-lg border border-dashed p-8 text-center">
            <h3 className="mb-2 text-xl font-medium">No tagged posts</h3>
            <p className="text-muted-foreground">When people tag you in photos, they will appear here.</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

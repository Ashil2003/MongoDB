import { NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

export async function GET() {
  try {
    const { client, db } = await connectToDatabase()

    // Try to ping the database to verify connection
    await db.command({ ping: 1 })

    return NextResponse.json({
      message: "Successfully connected to MongoDB",
      database: client.options.dbName,
    })
  } catch (error) {
    console.error("MongoDB connection error:", error)

    let errorMessage = "Failed to connect to MongoDB"
    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
